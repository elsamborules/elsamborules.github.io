import PinHolder from "./PinHolder";


export default class TargetPin extends PinHolder {
}
